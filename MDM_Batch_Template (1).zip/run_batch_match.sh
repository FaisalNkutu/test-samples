#!/bin/bash
BASE_DIR=$(dirname "$0")
"$BASE_DIR/config/runbatch.sh" \
-d /disk/apps/websphere/AppServer \
-u fxn703 \
-p 12JuneSummer969 \
-i "$BASE_DIR/input/persondata.unl" \
-r "$BASE_DIR/config/person_review.rev" \
-a "$BASE_DIR/config/person_automerge_profile.xml" \
-m PERSON \
-s Batch \
-t Default \
-l "$BASE_DIR/logs/match_log.txt" \
-b 5000
