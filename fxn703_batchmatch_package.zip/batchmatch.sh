#!/bin/bash

/disk/apps/mdm/BatchProcessor/bin/runbatch.sh \
-i /home/fxn703/input/persondata.unl \
-r /home/fxn703/config/person_review.rev \
-a /home/fxn703/config/person_automerge_profile.xml \
-l /home/fxn703/logs/match_log.txt \
-m PERSON \
-s Batch \
-t Default \
-b 5000
